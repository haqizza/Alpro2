#include "head.h"
/*Saya Muhammad Izzatul Haq mengerjakan evaluasi TP8 dalam mata kuliah Algoritma Pemgrograman 2 untuk keberkahanNya maka saya tidak melakukan kecurangan seperti yang telah dispesifikasikan. Aamiin.*/
int main(){
    int x=0,n[4];

    //Initialization (Manipulate Data, then Show Final Table and Menu)
    front(n);//Detailnya lihat di machine

    system("pause");
    return 0;
}  